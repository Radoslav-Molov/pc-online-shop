export default {
  maptiler: {
    url: "https://api.maptiler.com/maps/basic/256/{z}/{x}/{y}.png?key=9DwtLGNGVHAVfH8ox1n9",
    attribute:
      "https://api.maptiler.com/maps/basic/256/{z}/{x}/{y}.png?key=9DwtLGNGVHAVfH8ox1n9",
  },
};
