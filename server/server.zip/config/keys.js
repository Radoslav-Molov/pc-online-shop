module.exports = {
  mongoURI:
    "mongodb+srv://rado:123123123@compute-yourself.zp8kc.mongodb.net/myFirstDatabase?retryWrites=true&w=majority",
};
